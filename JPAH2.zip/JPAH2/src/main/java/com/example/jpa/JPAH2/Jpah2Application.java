package com.example.jpa.JPAH2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Jpah2Application {

	public static void main(String[] args) {
		SpringApplication.run(Jpah2Application.class, args);
	}

}
