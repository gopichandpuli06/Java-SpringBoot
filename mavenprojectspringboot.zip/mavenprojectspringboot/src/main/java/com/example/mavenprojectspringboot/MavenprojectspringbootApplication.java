package com.example.mavenprojectspringboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MavenprojectspringbootApplication {

	public static void main(String[] args) {
		SpringApplication.run(MavenprojectspringbootApplication.class, args);
	}

}
