package com.example.mavenprojectspringboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MavenprojectspringbootApplicationTests {

	@Test
	void contextLoads() {
	}

}
