package com.example.ChatWithAI;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ChatWithAiApplication {

	public static void main(String[] args) {
		SpringApplication.run(ChatWithAiApplication.class, args);
	}

}
